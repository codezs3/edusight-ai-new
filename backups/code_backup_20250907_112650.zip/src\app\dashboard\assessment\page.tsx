'use client';

import React, { useState } from 'react';
import { useSession } from 'next-auth/react';
import { toast } from 'react-hot-toast';
import {
  SparklesIcon,
  DocumentTextIcon,
  ChartBarIcon,
  UserGroupIcon,
  AcademicCapIcon,
  CloudArrowUpIcon,
  EyeIcon,
  ArrowRightIcon
} from '@heroicons/react/24/outline';
import UnifiedAssessmentWorkflow from '@/components/workflow/UnifiedAssessmentWorkflow';
import { getUserTypeConfig, canAccessAdminFeatures } from '@/lib/user-types';

export default function UnifiedAssessmentPage() {
  const { data: session } = useSession();
  const [showWorkflow, setShowWorkflow] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState<string>('');

  const userRole = session?.user?.role || '';
  const userTypeConfig = getUserTypeConfig(userRole);
  const isAdmin = canAccessAdminFeatures(userRole);

  const handleStartAssessment = (studentName: string) => {
    setSelectedStudent(studentName);
    setShowWorkflow(true);
  };

  const handleWorkflowComplete = (results: any) => {
    toast.success('Assessment completed successfully!');
    // You can add additional logic here to save results or redirect
  };

  const handleWorkflowError = (error: string) => {
    toast.error(`Assessment failed: ${error}`);
    setShowWorkflow(false);
  };

  if (showWorkflow) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Assessment Analysis</h1>
            <p className="text-gray-600">Processing assessment for {selectedStudent}</p>
          </div>
          <button
            onClick={() => setShowWorkflow(false)}
            className="text-gray-500 hover:text-gray-700"
          >
            ← Back to Assessment
          </button>
        </div>
        
        <UnifiedAssessmentWorkflow
          userRole={userRole as any}
          studentName={selectedStudent}
          onComplete={handleWorkflowComplete}
          onError={handleWorkflowError}
          showUpload={true}
        />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">
          EduSight 360° Assessment
        </h1>
        <p className="text-lg text-gray-600 mb-8 max-w-3xl mx-auto">
          Comprehensive AI-powered analysis of academic performance, physical health, and psychological development. 
          Get detailed insights, career recommendations, and personalized improvement plans.
        </p>
        
        {/* User Type Info */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-8 max-w-2xl mx-auto">
          <div className="flex items-center justify-center space-x-2 text-blue-800">
            <SparklesIcon className="w-5 h-5" />
            <span className="font-medium">{userTypeConfig.name} Access</span>
            <span className="text-blue-600">•</span>
            <span className="text-sm">
              {isAdmin ? 'Full Access - No Payment Required' : 'Standard Access'}
            </span>
          </div>
        </div>
      </div>

      {/* Assessment Process Overview */}
      <div className="bg-white rounded-xl shadow-lg p-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">
          How the Assessment Works
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CloudArrowUpIcon className="w-8 h-8 text-blue-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">1. Upload Documents</h3>
            <p className="text-gray-600">
              Upload report cards, transcripts, assessment results, or certificates. 
              Our AI supports multiple formats and frameworks.
            </p>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <SparklesIcon className="w-8 h-8 text-green-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">2. AI Analysis</h3>
            <p className="text-gray-600">
              Advanced machine learning algorithms analyze academic patterns, 
              identify strengths, and detect areas for improvement.
            </p>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <ChartBarIcon className="w-8 h-8 text-purple-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">3. Get Insights</h3>
            <p className="text-gray-600">
              Receive comprehensive reports with 360° scores, career recommendations, 
              and actionable improvement strategies.
            </p>
          </div>
        </div>
      </div>

      {/* Quick Start Options */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Individual Assessment */}
        <div className="bg-white rounded-xl shadow-lg p-8">
          <div className="flex items-center mb-6">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
              <UserGroupIcon className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900">Individual Assessment</h3>
              <p className="text-gray-600">Analyze a single student's performance</p>
            </div>
          </div>
          
          <div className="space-y-4 mb-6">
            <div className="flex items-center space-x-3">
              <DocumentTextIcon className="w-5 h-5 text-green-500" />
              <span className="text-sm text-gray-600">Upload academic documents</span>
            </div>
            <div className="flex items-center space-x-3">
              <ChartBarIcon className="w-5 h-5 text-green-500" />
              <span className="text-sm text-gray-600">Get 360° performance analysis</span>
            </div>
            <div className="flex items-center space-x-3">
              <EyeIcon className="w-5 h-5 text-green-500" />
              <span className="text-sm text-gray-600">Receive detailed insights</span>
            </div>
          </div>
          
          <button
            onClick={() => handleStartAssessment('Sample Student')}
            className="w-full bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2"
          >
            <SparklesIcon className="w-5 h-5" />
            <span>Start Individual Assessment</span>
          </button>
        </div>

        {/* Batch Assessment */}
        <div className="bg-white rounded-xl shadow-lg p-8">
          <div className="flex items-center mb-6">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mr-4">
              <AcademicCapIcon className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900">Batch Assessment</h3>
              <p className="text-gray-600">Analyze multiple students at once</p>
            </div>
          </div>
          
          <div className="space-y-4 mb-6">
            <div className="flex items-center space-x-3">
              <CloudArrowUpIcon className="w-5 h-5 text-green-500" />
              <span className="text-sm text-gray-600">Upload multiple documents</span>
            </div>
            <div className="flex items-center space-x-3">
              <ChartBarIcon className="w-5 h-5 text-green-500" />
              <span className="text-sm text-gray-600">Compare performance across students</span>
            </div>
            <div className="flex items-center space-x-3">
              <ArrowRightIcon className="w-5 h-5 text-green-500" />
              <span className="text-sm text-gray-600">Generate comparative reports</span>
            </div>
          </div>
          
          <button
            onClick={() => handleStartAssessment('Multiple Students')}
            className="w-full bg-green-600 text-white py-3 px-6 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center space-x-2"
          >
            <SparklesIcon className="w-5 h-5" />
            <span>Start Batch Assessment</span>
          </button>
        </div>
      </div>

      {/* Features Grid */}
      <div className="bg-white rounded-xl shadow-lg p-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">
          Assessment Features
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="text-center p-6 border border-gray-200 rounded-lg">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <DocumentTextIcon className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Multi-Format Support</h3>
            <p className="text-sm text-gray-600">
              Supports PDFs, images, Word documents, and Excel files
            </p>
          </div>
          
          <div className="text-center p-6 border border-gray-200 rounded-lg">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <SparklesIcon className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">AI-Powered Analysis</h3>
            <p className="text-sm text-gray-600">
              Advanced machine learning for accurate performance insights
            </p>
          </div>
          
          <div className="text-center p-6 border border-gray-200 rounded-lg">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <ChartBarIcon className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">360° Scoring</h3>
            <p className="text-sm text-gray-600">
              Comprehensive academic, physical, and psychological assessment
            </p>
          </div>
          
          <div className="text-center p-6 border border-gray-200 rounded-lg">
            <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <EyeIcon className="w-6 h-6 text-yellow-600" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Career Mapping</h3>
            <p className="text-sm text-gray-600">
              AI-powered career recommendations based on strengths
            </p>
          </div>
          
          <div className="text-center p-6 border border-gray-200 rounded-lg">
            <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <ArrowRightIcon className="w-6 h-6 text-red-600" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Actionable Insights</h3>
            <p className="text-sm text-gray-600">
              Personalized recommendations for improvement
            </p>
          </div>
          
          <div className="text-center p-6 border border-gray-200 rounded-lg">
            <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <UserGroupIcon className="w-6 h-6 text-indigo-600" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Multi-User Support</h3>
            <p className="text-sm text-gray-600">
              Works for parents, schools, and administrators
            </p>
          </div>
        </div>
      </div>

      {/* User Type Specific Information */}
      {!isAdmin && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
          <div className="flex items-start">
            <div className="flex-shrink-0">
              <SparklesIcon className="h-5 w-5 text-yellow-400" />
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-yellow-800">
                {userTypeConfig.name} Access Level
              </h3>
              <div className="mt-2 text-sm text-yellow-700">
                <p>
                  You have access to standard assessment features. 
                  {userTypeConfig.features.paymentRequired && ' Some advanced features may require a subscription.'}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
