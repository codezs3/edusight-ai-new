'use client';

import React from 'react';
import EnhancedUnifiedWorkflow from '@/components/workflow/EnhancedUnifiedWorkflow';

export default function AssessmentEnhancedPage() {
  return <EnhancedUnifiedWorkflow userRole="PARENT" />;
}
