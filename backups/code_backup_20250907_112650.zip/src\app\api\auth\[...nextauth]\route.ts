import { handlers } from '@/lib/auth-new';

export const { GET, POST } = handlers;
