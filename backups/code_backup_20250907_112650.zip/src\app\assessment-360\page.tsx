'use client';

import React from 'react';
import { Edusight360Workflow } from '@/components/workflow/Edusight360Workflow';

export default function Assessment360Page() {
  return <Edusight360Workflow />;
}
