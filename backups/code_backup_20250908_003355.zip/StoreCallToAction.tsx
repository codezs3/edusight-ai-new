'use client';

import Link from 'next/link';
import { 
  ShoppingBagIcon, 
  SparklesIcon, 
  ArrowRightIcon,
  StarIcon,
  UserGroupIcon,
  ChartBarIcon
} from '@heroicons/react/24/outline';
import { StarIcon as StarSolidIcon } from '@heroicons/react/24/solid';

export function StoreCallToAction() {
  return (
    <section className="relative bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 py-20 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-10 left-10 w-20 h-20 bg-blue-200 rounded-full opacity-20 animate-pulse"></div>
        <div className="absolute top-32 right-20 w-16 h-16 bg-purple-200 rounded-full opacity-20 animate-pulse delay-1000"></div>
        <div className="absolute bottom-20 left-1/4 w-12 h-12 bg-indigo-200 rounded-full opacity-20 animate-pulse delay-2000"></div>
        <div className="absolute bottom-32 right-1/3 w-24 h-24 bg-pink-200 rounded-full opacity-20 animate-pulse delay-500"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-white/80 backdrop-blur-sm rounded-full px-4 py-2 mb-6 shadow-lg">
            <ShoppingBagIcon className="h-5 w-5 text-blue-600" />
            <span className="text-sm font-medium text-gray-700">New Store Launch</span>
            <SparklesIcon className="h-4 w-4 text-yellow-500" />
          </div>
          
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Discover Your Perfect
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent"> Assessment</span>
          </h2>
          
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
            Explore our comprehensive library of 1000+ assessments designed by experts. 
            From academic excellence to career guidance, find the perfect test for your journey.
          </p>

          {/* Stats */}
          <div className="flex flex-wrap justify-center items-center gap-8 mb-12">
            <div className="flex items-center space-x-2 bg-white/60 backdrop-blur-sm rounded-lg px-4 py-2 shadow-sm">
              <ChartBarIcon className="h-5 w-5 text-blue-600" />
              <span className="text-sm font-medium text-gray-700">1000+ Tests</span>
            </div>
            <div className="flex items-center space-x-2 bg-white/60 backdrop-blur-sm rounded-lg px-4 py-2 shadow-sm">
              <UserGroupIcon className="h-5 w-5 text-green-600" />
              <span className="text-sm font-medium text-gray-700">24 Categories</span>
            </div>
            <div className="flex items-center space-x-2 bg-white/60 backdrop-blur-sm rounded-lg px-4 py-2 shadow-sm">
              <StarSolidIcon className="h-5 w-5 text-yellow-500" />
              <span className="text-sm font-medium text-gray-700">4.8/5 Rating</span>
            </div>
          </div>
        </div>

        {/* Featured Tests Preview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center mb-4">
              <SparklesIcon className="h-6 w-6 text-white" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Academic Excellence</h3>
            <p className="text-gray-600 text-sm mb-4">Comprehensive assessments for all subjects and grade levels</p>
            <div className="flex items-center justify-between">
              <span className="text-2xl font-bold text-blue-600">₹99</span>
              <div className="flex items-center space-x-1">
                <StarSolidIcon className="h-4 w-4 text-yellow-400" />
                <span className="text-sm text-gray-600">4.9</span>
              </div>
            </div>
          </div>

          <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg flex items-center justify-center mb-4">
              <UserGroupIcon className="h-6 w-6 text-white" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Personality Insights</h3>
            <p className="text-gray-600 text-sm mb-4">Discover your unique personality traits and strengths</p>
            <div className="flex items-center justify-between">
              <span className="text-2xl font-bold text-purple-600">₹99</span>
              <div className="flex items-center space-x-1">
                <StarSolidIcon className="h-4 w-4 text-yellow-400" />
                <span className="text-sm text-gray-600">4.8</span>
              </div>
            </div>
          </div>

          <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-lg flex items-center justify-center mb-4">
              <ChartBarIcon className="h-6 w-6 text-white" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Career Guidance</h3>
            <p className="text-gray-600 text-sm mb-4">AI-powered career recommendations and path mapping</p>
            <div className="flex items-center justify-between">
              <span className="text-2xl font-bold text-green-600">₹99</span>
              <div className="flex items-center space-x-1">
                <StarSolidIcon className="h-4 w-4 text-yellow-400" />
                <span className="text-sm text-gray-600">4.7</span>
              </div>
            </div>
          </div>
        </div>

        {/* CTA Buttons */}
        <div className="text-center">
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              href="/testvault"
              className="group inline-flex items-center justify-center px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
            >
              <ShoppingBagIcon className="h-5 w-5 mr-2" />
              Explore TestVault
              <ArrowRightIcon className="h-5 w-5 ml-2 group-hover:translate-x-1 transition-transform" />
            </Link>
            
            <Link
              href="/testvault?filter=free"
              className="inline-flex items-center justify-center px-8 py-4 bg-white/80 backdrop-blur-sm text-gray-700 font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border border-gray-200"
            >
              Try Free Tests
            </Link>
          </div>
          
          <p className="text-sm text-gray-500 mt-4">
            No payment required • Instant access • Detailed reports
          </p>
        </div>
      </div>
    </section>
  );
}
